---
layout: page
title: "CV"
---

You can download my full CV here:  
[📄 Download CV (PDF)](/assets/CV.pdf)
